<?php $tab = [
    ["val"=>"Profile","key"=>"profile"],
    ["val"=>"About","key"=>"about"],
    ["val"=>"Footer_Kiri","key"=>"footer1"],
    ["val"=>"Footer_Tengah","key"=>"footer2"],
    ["val"=>"Footer_Kanan","key"=>"footer3"],
]; ?>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-border panel-primary">
            <form id="form_input">
                
            </form>
            <div class="tabs-vertical-env"> 
                <ul class="nav tabs-vertical">
                    <?php  foreach($result as $key=>$val): ?> 
                    <li class="tab-head <?=$key==0?'active':''?>">
                        <a href="#<?=$val['id']?>" data-toggle="tab" aria-expanded="false" onclick="tabChange('<?=$key?>')"><?=$val["sidebar"]?></a>
                    </li> 
                    <?php endforeach; ?>
                </ul> 
                    <div class="tab-content" style="width:1000px"> 
                    
                    <?php foreach($result as $key=>$val): ?> 
                        <div class="tab-pane <?=$key==0?'active':''?> " id="<?=$val['id']?>"> 
                            <form method="post" action="<?=base_url('backoffice/master-konten/lainnya/simpan')?>" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="">Title</label>
                                    <input type="text" name="title" id="title_<?=$val['id']?>" class="form-control" value="<?=$val["title"]?>">
                                    <input type="hidden" name="id" id="id_<?=$val['id']?>" class="form-control" value="<?=$val["id"]?>">
                                </div>
                                <textarea name="desc" id="desc_<?=$val['id']?>" style="border:1px solid red;width:1000px"></textarea>
                                <div class="form-group">
                                    <?php $label = 'file_upload'; ?>
                                    <label>Gambar</label>
                                    <input type="hidden" id="<?= $label ?>ed" name="<?= $label ?>ed<?=$val['id']?>" />
                                    <input type="file" class="form-control" id="<?= $label.'_'.$val['id'] ?>" name="<?= $label.''.$val["id"] ?>"
                                        onchange="return ValidateFileUpload(`file_upload_<?=$val['id']?>`,`result_image_<?=$val['id']?>`)" accept="image/*">
                                    <img class="img-responsive" src="<?= base_url() .'assets/no_image.png' ?>" id="result_image_<?=$val['id']?>">
                                </div>
                                
                                <button type="submit" class="btn btn-primary" style="float:right">Simpan</button>

                            </form>
                        </div> 
                    <?php endforeach; ?>
                    <br/>
                    <!-- <button onclick="save()" class="btn btn-primary" style="float:right">Simpan</button> -->
                </div>
            </div> 
        </div>
    </div>
</div>
<input type="hidden" name="tabActive" id="tabActive">

<script>

    
    let arrayPush=<?=json_encode($result)?>;
    let actived=0;
    function setImg(val){
        $("#file_uploaded").val(arrayPush[val]["image"] != ""? arrayPush[val]["image"]: "");
        $("#result_image_"+arrayPush[val]["id"]).attr("src",base_assets +(arrayPush[val]["image"] != ""? arrayPush[val]["image"]: "assets/no_image.png"));
    }
    $(document).ready(function(){
        
        setTimeout(() => {
            for(let i=0;i < arrayPush.length; i++){
                CKEDITOR.replace("desc_"+arrayPush[i].id,{
                    height: '500px'
                });
            }
            tabChange(0);
            setImg(0);
            console.log("lagi");
            actived= 0;
        }, 400);
        setTimeout(() => {
            console.log("lagi bus",actived);
            $("#form_input_"+actived).submit(function(e){
            e.preventDefault();
            var myForm = document.getElementClassName("form_input");
            _ajax_file(
            	`simpan`,
            	new FormData(myForm),
            	function (res) {
            		if (res.status) {
            			// load_data(1, {});
            			notif("success");
            			// $(`#modal_form`).modal("hide");
            			// $(`#form_input`)[0].reset();
            			// $("#param").val("add");
            		} else {
            			notif("failed");
            		}
            	}
            );

        })
        }, 500);
       
        
        
        
    })
    function tabChange(param){
        CKEDITOR.instances[`desc_${arrayPush[param]["id"]}`].setData(arrayPush[param]["desc"]);
        $("#tabActive").val(param);
        setImg(param);
        $("#form_input_"+param);
        reloadActived(param);
        
    }

    function reloadActived(param){
        actived= param;
        console.log(actived);
    }

     

    // function save(){
    //     var type=$("#tabActive").val();
    //     var desc = CKEDITOR.instances[`desc_${arrayPush[type]["id"]}`].getData();
    //     var title = $("#title_"+arrayPush[type]["id"]).val();
    //     var image = $("#file_upload")[0].files[0];
    //     console.log(image);
    //      _ajax_file("simpan",{desc:desc,title:title,file_upload:image},function(res){
    //         if (res.status) {
    //             CKEDITOR.instances[`desc_${arrayPush[type]["id"]}`].setData(desc);
    //             tabChange(type);
    //             notif("success");
    //         } else {
    //             notif("failed");
    //         }
    //     })
    // }
</script>