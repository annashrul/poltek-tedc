<?php include 'header.php'; ?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
    <div class="main" style="margin-top: 116px;">
        <?php $this->load->view('fo/'.$content); ?>
    </div>
<?php include 'footer.php'; ?>